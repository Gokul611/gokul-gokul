package packageproject2;
import java.util.ArrayList;
import java.util.Scanner;
public class Validationemail {
		public static void main(String[] args) {
			Scanner input = new Scanner(System.in);
			ArrayList<String> mail = new ArrayList<String>();
			mail.add("gokul@gmail.com");
			mail.add("bhuvi@gmail.com");
			mail.add("dhaya@gmail.com");
			mail.add("yuvaraj@gmail.com");
			mail.add("vikramgo@gmail.com");
			System.out.println("ENTER USER EMAIL ID:");
			String userId = input.nextLine();
			//checks user mail id and shows found or not
				if (mail.contains(userId)) {
					System.out.println();
					System.out.println("Email ID " + userId + " found");
				} 
				else {
					System.out.println("Email ID " + userId + " Not found");

				}
			}
}
