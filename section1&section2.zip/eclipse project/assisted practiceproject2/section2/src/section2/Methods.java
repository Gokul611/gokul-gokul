package section2;

public class Methods {
           public int addNumbers(int x, int y) {
		    int sum = x + y;
		    return sum;
		  }
		  public static void main(String[] args) {
		    int num1 = 20;
		    int num2 = 20;
		    Methods obj = new Methods();
		    int result = obj.addNumbers(num1, num2);
		    System.out.println("Sum is: " + result);
		  }
		}


